Configured Example
=======

Basic read functions after custom device configuration example.
